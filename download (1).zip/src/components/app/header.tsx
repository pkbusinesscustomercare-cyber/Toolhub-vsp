import { SidebarTrigger } from '@/components/ui/sidebar';
import { Logo } from '@/components/icons/logo';

export function AppHeader({ groupName }: { groupName?: string }) {
  return (
    <header className="flex h-14 shrink-0 items-center gap-4 border-b bg-background px-4 sticky top-0 z-10 lg:h-[60px] lg:px-6">
      <div className="flex w-full items-center justify-between">
        <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 font-semibold text-lg">
                <Logo className="h-6 w-6 text-primary" />
                <span className="">TabVerse</span>
            </div>
            {groupName && <span className="hidden text-muted-foreground font-normal text-base md:inline-block">/ {groupName}</span>}
        </div>
        <div className="md:hidden">
            <SidebarTrigger />
        </div>
      </div>
    </header>
  );
}
