"use client";

import React from 'react';
import { useTabGroups } from '@/hooks/use-tab-groups';
import type { TabGroup } from '@/lib/types';
import { Button } from '@/components/ui/button';
import {
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuSkeleton,
} from '@/components/ui/sidebar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Trash2, LayoutGrid } from 'lucide-react';
import { AiSuggester } from './ai-suggester';
import { Logo } from '../icons/logo';
import { NewGroupDialog } from './new-group-dialog';

interface TabGroupsManagerProps {
  onSelectGroup: (group: TabGroup | null) => void;
  activeGroupId: string | undefined;
}

export function TabGroupsManager({ onSelectGroup, activeGroupId }: TabGroupsManagerProps) {
  const { tabGroups, deleteGroup, isLoaded } = useTabGroups();

  return (
    <>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2 font-semibold text-lg">
          <Logo className="h-7 w-7 text-primary" />
          <span className="text-foreground">TabVerse</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <ScrollArea className="h-full">
            <SidebarMenu>
                <SidebarMenuItem>
                    <NewGroupDialog>
                      <Button variant="outline" className="w-full justify-start gap-2">
                          <Plus size={16} /> New Group
                      </Button>
                    </NewGroupDialog>
                </SidebarMenuItem>
            </SidebarMenu>
          
          <div className="p-4 pt-2">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Groups</h3>
          </div>
          
          {!isLoaded ? (
            <div className="px-2 space-y-1">
                <SidebarMenuSkeleton showIcon />
                <SidebarMenuSkeleton showIcon />
                <SidebarMenuSkeleton showIcon />
            </div>
          ) : (
            <SidebarMenu>
              {tabGroups.map((group) => (
                <SidebarMenuItem key={group.id}>
                  <SidebarMenuButton
                    onClick={() => onSelectGroup(group)}
                    isActive={group.id === activeGroupId}
                    className="justify-between"
                  >
                    <div className="flex items-center gap-2 truncate">
                        <LayoutGrid size={16} />
                        <span className="truncate">{group.name}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 shrink-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (group.id === activeGroupId) {
                          onSelectGroup(null);
                        }
                        deleteGroup(group.id);
                      }}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          )}
        </ScrollArea>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <AiSuggester />
      </SidebarFooter>
    </>
  );
}
