"use client";

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { suggestTabGroups, type SuggestTabGroupsOutput } from '@/ai/flows/suggest-tab-groups';
import { useTabGroups } from '@/hooks/use-tab-groups';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { Sparkles, Plus, Loader2 } from 'lucide-react';

const formSchema = z.object({
  browsingHistory: z.string().min(50, {
    message: 'Please enter at least 50 characters of browsing history.',
  }),
});

export function AiSuggester() {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<SuggestTabGroupsOutput | null>(null);
  const { addGroup } = useTabGroups();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      browsingHistory: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setSuggestions(null);
    try {
      const result = await suggestTabGroups(values);
      setSuggestions(result);
    } catch (error) {
      console.error('AI suggestion failed:', error);
      toast({
        title: 'Suggestion Failed',
        description: 'Could not generate suggestions. Please try again later.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  const handleSaveGroup = (groupName: string, urls: string[]) => {
    addGroup(groupName, urls);
    toast({
      title: 'Group Saved!',
      description: `The group "${groupName}" has been added to your list.`,
    });
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button className="w-full justify-center gap-2">
          <Sparkles size={16} />
          <span>AI Suggestions</span>
        </Button>
      </SheetTrigger>
      <SheetContent className="sm:max-w-xl flex flex-col">
        <SheetHeader>
          <SheetTitle>AI-Powered Suggestions</SheetTitle>
          <SheetDescription>
            Paste your browsing history below and let our AI suggest new tab groups for you.
          </SheetDescription>
        </SheetHeader>
        <div className="flex-1 min-h-0">
            <ScrollArea className="h-full pr-6">
                <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                    control={form.control}
                    name="browsingHistory"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Browsing History</FormLabel>
                        <FormControl>
                            <Textarea
                            placeholder="e.g., visit to wikipedia.org, then react.dev, then tailwindcss.com..."
                            className="min-h-[120px] font-code"
                            {...field}
                            />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <Button type="submit" disabled={isLoading} className="w-full">
                    {isLoading ? <Loader2 className="animate-spin" /> : 'Generate Suggestions'}
                    </Button>
                </form>
                </Form>

                {suggestions && (
                <div className="mt-6 space-y-4">
                    <h4 className="font-semibold">Suggested Groups</h4>
                    {suggestions.suggestedTabGroups.map((group, index) => (
                    <Card key={index}>
                        <CardHeader>
                        <CardTitle>{group.groupName}</CardTitle>
                        <CardDescription>{group.reason}</CardDescription>
                        </CardHeader>
                        <CardContent>
                        <Accordion type="single" collapsible>
                            <AccordionItem value="urls">
                            <AccordionTrigger>{group.urls.length} URLs</AccordionTrigger>
                            <AccordionContent>
                                <ul className="list-disc pl-5 space-y-1 font-code text-sm">
                                {group.urls.map((url, i) => (
                                    <li key={i} className="truncate"><a href={url} target="_blank" rel="noopener noreferrer" className="hover:underline text-primary">{url}</a></li>
                                ))}
                                </ul>
                            </AccordionContent>
                            </AccordionItem>
                        </Accordion>
                        </CardContent>
                        <CardFooter>
                        <Button
                            variant="outline"
                            className="w-full gap-2"
                            onClick={() => handleSaveGroup(group.groupName, group.urls)}
                        >
                            <Plus size={16} /> Save Group
                        </Button>
                        </CardFooter>
                    </Card>
                    ))}
                </div>
                )}
            </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
}
