"use client";

import { WebView } from './web-view';
import { LayoutGrid, MousePointerClick } from 'lucide-react';

interface WebViewGridProps {
  urls: string[] | undefined;
}

export function WebViewGrid({ urls }: WebViewGridProps) {
  if (!urls || urls.length === 0) {
    return (
      <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed shadow-sm m-4">
        <div className="flex flex-col items-center gap-2 text-center">
          <LayoutGrid className="h-12 w-12 text-muted-foreground" />
          <h3 className="text-2xl font-bold tracking-tight">
            No Group Selected
          </h3>
          <p className="text-sm text-muted-foreground max-w-sm">
            Select a tab group from the sidebar to start browsing, create a new group, or use the quick open bar above.
          </p>
          <div className="flex items-center gap-2 text-muted-foreground mt-2">
            <MousePointerClick size={16} />
            <span>Select or create a group</span>
          </div>
        </div>
      </div>
    );
  }

  const gridCols = urls.length > 1 ? 'lg:grid-cols-2' : 'lg:grid-cols-1';

  return (
    <div className={`grid flex-1 grid-cols-1 ${gridCols} gap-4 p-4 overflow-auto`}>
      {urls.map((url, index) => (
        <WebView key={`${url}-${index}`} url={url} />
      ))}
    </div>
  );
}
