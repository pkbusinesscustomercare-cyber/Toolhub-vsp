"use client";

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ExternalLink } from "lucide-react";

interface WebViewProps {
    url: string;
}

export function WebView({ url }: WebViewProps) {
    return (
        <Card className="flex flex-col min-h-[300px]">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 p-2 border-b">
                <p className="text-xs text-muted-foreground font-code truncate px-2">{url}</p>
                <a href={url} target="_blank" rel="noopener noreferrer" className="p-2 text-muted-foreground hover:text-foreground">
                    <ExternalLink size={14}/>
                </a>
            </CardHeader>
            <CardContent className="p-0 flex-1">
                <iframe
                    src={url}
                    className="w-full h-full border-0"
                    title={`Web view for ${url}`}
                    sandbox="allow-forms allow-modals allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation"
                    referrerPolicy="no-referrer"
                />
            </CardContent>
        </Card>
    );
}
