"use client";

import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Loader2, Link, AppWindow } from 'lucide-react';

const formSchema = z.object({
  url: z.string().url({ message: 'Please enter a valid URL.' }),
  count: z.coerce.number().min(1, { message: 'Enter at least 1.' }),
});

interface QuickOpenBarProps {
  onQuickOpen: (urls: string[]) => void;
}

export function QuickOpenBar({ onQuickOpen }: QuickOpenBarProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      url: '',
      count: 1,
    },
  });

  const { isSubmitting } = form.formState;

  function onSubmit(values: z.infer<typeof formSchema>) {
    const urls = Array(values.count).fill(values.url);
    onQuickOpen(urls);
  }

  return (
    <div className="border-b bg-background px-4 py-2 sticky top-14 lg:top-[60px] z-10">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-start gap-2">
          <FormField
            control={form.control}
            name="url"
            render={({ field }) => (
              <FormItem className="flex-1">
                <div className="relative">
                  <Link className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <FormControl>
                    <Input placeholder="https://example.com" {...field} className="pl-9" />
                  </FormControl>
                </div>
                <FormMessage className="text-xs" />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="count"
            render={({ field }) => (
              <FormItem className="w-32">
                 <div className="relative">
                    <AppWindow className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <FormControl>
                        <Input type="number" min="1" {...field} className="pl-9" />
                    </FormControl>
                 </div>
                <FormMessage className="text-xs" />
              </FormItem>
            )}
          />
          <Button type="submit" disabled={isSubmitting} className="h-10">
            {isSubmitting ? <Loader2 className="animate-spin" /> : 'Go'}
          </Button>
        </form>
      </Form>
    </div>
  );
}
