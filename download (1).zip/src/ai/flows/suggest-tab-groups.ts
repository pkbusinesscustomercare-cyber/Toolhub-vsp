'use server';

/**
 * @fileOverview An AI agent that suggests new tab groups based on the user's browsing history.
 *
 * - suggestTabGroups - A function that suggests new tab groups.
 * - SuggestTabGroupsInput - The input type for the suggestTabGroups function.
 * - SuggestTabGroupsOutput - The return type for the suggestTabGroups function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestTabGroupsInputSchema = z.object({
  browsingHistory: z
    .string()
    .describe('The user browsing history as a text.'),
});

export type SuggestTabGroupsInput = z.infer<typeof SuggestTabGroupsInputSchema>;

const SuggestedTabGroupSchema = z.object({
  groupName: z.string().describe('The name of the suggested tab group.'),
  urls: z.array(z.string().url()).describe('The URLs for the suggested tab group.'),
  reason: z.string().describe('The reasoning behind the suggestion.'),
});

const SuggestTabGroupsOutputSchema = z.object({
  suggestedTabGroups: z.array(SuggestedTabGroupSchema).describe('The suggested tab groups.'),
});

export type SuggestTabGroupsOutput = z.infer<typeof SuggestTabGroupsOutputSchema>;

export async function suggestTabGroups(input: SuggestTabGroupsInput): Promise<SuggestTabGroupsOutput> {
  return suggestTabGroupsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestTabGroupsPrompt',
  input: {schema: SuggestTabGroupsInputSchema},
  output: {schema: SuggestTabGroupsOutputSchema},
  prompt: `You are a tab group suggestion agent. Given the user's browsing history, suggest new tab groups that the user may find interesting or helpful.

Suggest at least three tab groups. For each tab group, provide a name and a list of relevant URLs, and a reason for the suggestion.

User Browsing History:
{{{browsingHistory}}}`,
});

const suggestTabGroupsFlow = ai.defineFlow(
  {
    name: 'suggestTabGroupsFlow',
    inputSchema: SuggestTabGroupsInputSchema,
    outputSchema: SuggestTabGroupsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
