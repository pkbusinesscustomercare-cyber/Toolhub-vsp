import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-tab-groups.ts';