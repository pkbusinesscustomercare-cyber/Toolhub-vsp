"use client";

import { useState, useEffect, useCallback } from 'react';
import type { TabGroup } from '@/lib/types';

const STORAGE_KEY = 'tabverse_tab_groups';

export function useTabGroups() {
  const [tabGroups, setTabGroups] = useState<TabGroup[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    try {
      const storedGroups = window.localStorage.getItem(STORAGE_KEY);
      if (storedGroups) {
        setTabGroups(JSON.parse(storedGroups));
      }
    } catch (error) {
      console.error("Failed to load tab groups from localStorage", error);
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(tabGroups));
      } catch (error) {
        console.error("Failed to save tab groups to localStorage", error);
      }
    }
  }, [tabGroups, isLoaded]);

  const addGroup = useCallback((name: string, urls: string[]) => {
    const newGroup: TabGroup = {
      id: crypto.randomUUID(),
      name,
      urls,
    };
    setTabGroups(prev => [...prev, newGroup]);
    return newGroup;
  }, []);

  const updateGroup = useCallback((id: string, name: string, urls: string[]) => {
    setTabGroups(prev => 
      prev.map(group => group.id === id ? { ...group, name, urls } : group)
    );
  }, []);

  const deleteGroup = useCallback((id: string) => {
    setTabGroups(prev => prev.filter(group => group.id !== id));
  }, []);
  
  return { tabGroups, addGroup, updateGroup, deleteGroup, isLoaded };
}
