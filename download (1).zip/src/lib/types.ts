export type TabGroup = {
  id: string;
  name: string;
  urls: string[];
};
