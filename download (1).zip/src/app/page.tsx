"use client";

import React, { useState } from 'react';
import { Sidebar, SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import type { TabGroup } from '@/lib/types';
import { AppHeader } from '@/components/app/header';
import { TabGroupsManager } from '@/components/app/tab-groups-manager';
import { WebViewGrid } from '@/components/app/web-view-grid';
import { QuickOpenBar } from '@/components/app/quick-open-bar';

export default function Home() {
  const [activeGroup, setActiveGroup] = useState<TabGroup | null>(null);

  const handleQuickOpen = (urls: string[]) => {
    setActiveGroup({
      id: 'quick-open',
      name: 'Quick Open',
      urls: urls,
    });
  };

  return (
    <SidebarProvider>
      <Sidebar>
        <TabGroupsManager onSelectGroup={setActiveGroup} activeGroupId={activeGroup?.id} />
      </Sidebar>
      <SidebarInset>
        <AppHeader groupName={activeGroup?.name} />
        <QuickOpenBar onQuickOpen={handleQuickOpen} />
        <WebViewGrid urls={activeGroup?.urls} />
      </SidebarInset>
    </SidebarProvider>
  );
}
